#include "StudentWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{

}

StudentWorld::~StudentWorld()
{
	cleanUp();
}

int StudentWorld::init() {
	int numNeedSave;
	switch (convertLevel()) {
	case 4:
		return GWSTATUS_LEVEL_ERROR;
		break;
	case 1:
		return GWSTATUS_CONTINUE_GAME;
		break;
	default: 
		return GWSTATUS_LEVEL_ERROR;
		break;
	}
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit enter.
    // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.

    //decLives();
	p->doSomething();
	for (list<Actor*>::iterator p = actors.begin(); p != actors.end(); p++)
		(*p)->doSomething();
    //return GWSTATUS_PLAYER_DIED;
	return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
	delete p;
	for (list<Actor*>::iterator p = actors.begin(); p != actors.end();)
		p = actors.erase(p);
}

int StudentWorld::convertLevel() {
	Level lev(assetPath());

	string levelFile = "level01.txt";
	Level::LoadResult result = lev.loadLevel(levelFile);

	if (result == Level::load_fail_file_not_found)
		//cerr << "Cannot find level01.txt data file" << endl;
		return 4;
	else if (result == Level::load_fail_bad_format)
		//cerr << "Your level was improperly formatted" << endl;
		return 4;
	else if (result == Level::load_success)
	{
		//cerr << "Successfully loaded level" << endl;
		for (int i = 0; i < LEVEL_WIDTH; i++) {
			for (int j = 0; j < LEVEL_HEIGHT; j++) {
				Level::MazeEntry ge = lev.getContentsOf(i, j); // level_x=5, level_y=10
				switch (ge) // so x=80 and y=160
				{
					/*case Level::empty:
						cout << "Location 80,160 is empty" << endl;
						break;
					case Level::smart_zombie:
						cout << "Location 80,160 starts with a smart zombie" << endl;
						break;
					case Level::dumb_zombie:
						cout << "Location 80,160 starts with a dumb zombie" << endl;
						break;*/
				case Level::player:
				//	cout << "Location 80,160 is where Penelope starts" << endl;
					p = new Penelope(i * SPRITE_WIDTH, j* SPRITE_HEIGHT, this);
					penelope.push_back(p);
					break;
					/*case Level::exit:
						cout << "Location 80,160 is where an exit is" << endl;
						break;*/
				case Level::wall:
					actors.push_back(new Wall(i * SPRITE_WIDTH, j * SPRITE_HEIGHT, this));
					break;
					/*case Level::pit:
						cout << "Location 80,160 has a pit in the ground" << endl;
						break;*/
						// etc�
				}
			}
		}
	}
	return 1;
}

bool StudentWorld::isBlocked(int x, int y, int dir) {
	for (list<Actor*>::iterator i = actors.begin(); i != actors.end(); i++) {
		switch (dir) {
		case right:
			if ((y >= (*i)->getY() && y < (*i)->getY() + SPRITE_HEIGHT ||
				y + SPRITE_HEIGHT > (*i)->getY() && y + SPRITE_HEIGHT <= (*i)->getY() + SPRITE_HEIGHT)
				&& (x + SPRITE_WIDTH >= (*i)->getX() && x + SPRITE_WIDTH <= (*i)->getX() + SPRITE_WIDTH))
				return true;
			break;
		case left:
			if ((y >= (*i)->getY() && y < (*i)->getY() + SPRITE_HEIGHT ||
				y + SPRITE_HEIGHT >(*i)->getY() && y + SPRITE_HEIGHT <= (*i)->getY() + SPRITE_HEIGHT)
				&& (x <= (*i)->getX() + SPRITE_WIDTH && x >= (*i)->getX()))
				return true;
			break;
		case up:
			if ((x >= (*i)->getX() && x < (*i)->getX() + SPRITE_WIDTH ||
				x + SPRITE_WIDTH > (*i)->getX() && x + SPRITE_WIDTH <= (*i)->getX() + SPRITE_WIDTH)
				&& (y + SPRITE_HEIGHT <= (*i)->getY() + SPRITE_HEIGHT && y + SPRITE_HEIGHT >= (*i)->getY()))
				return true;
			break;
		case down:
			if ((x >= (*i)->getX() && x < (*i)->getX() + SPRITE_WIDTH ||
				x + SPRITE_WIDTH >(*i)->getX() && x + SPRITE_WIDTH <= (*i)->getX() + SPRITE_WIDTH)
				&& (y <= (*i)->getY() + SPRITE_HEIGHT && y >= (*i)->getY()))
				return true;
			break;
		default: break;
		}
	}
	return false;	
}
