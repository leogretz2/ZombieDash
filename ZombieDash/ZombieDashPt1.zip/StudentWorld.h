#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Level.h"
//#include "Actor.h"

class Actor;
class Penelope;

#include <list>
#include <vector>
#include <string>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:

	static const int right = 0;
	static const int left = 180;
	static const int up = 90;
	static const int down = 270;

    StudentWorld(std::string assetPath);
	~StudentWorld();
    virtual int init();
    virtual int move();
    virtual void cleanUp();
	bool isBlocked(int x, int y, int dir);

private:
	Penelope* p;
	//int start_x;
	//int start_y;
	std::list<Actor*> actors;
	std::list<Actor*> penelope;
	//GameWorld* sw;
	int convertLevel();
};

#endif // STUDENTWORLD_H_
