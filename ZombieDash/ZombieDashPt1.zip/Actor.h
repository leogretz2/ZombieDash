#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

class StudentWorld;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class Actor : public GraphObject {
public:
	Actor(int imageID, double x, double y, int dir, int depth, StudentWorld* sw) :
		GraphObject(imageID, x, y, dir, depth), m_sw(sw) {}
	virtual ~Actor() {}
	virtual void doSomething() = 0;
	StudentWorld* getWorld(){return m_sw;}

private:
	int imageID;
	//int m_x;
	//int m_y;
	StudentWorld* m_sw;
};


class Wall : public Actor {
public:
	Wall(int x, int y, StudentWorld* sw) : Actor(IID_WALL, x, y, right, 0, sw)/*, m_dir(right), depth(0)*/ {}
	virtual void doSomething() { return; }

private:
	//int m_x;
	//int m_y;
	//int m_dir;
	//int depth;
	//bool m_alive;
};

class Penelope : public Actor {
public:
	Penelope(int x, int y, StudentWorld* sw) : Actor(IID_PLAYER, x, y, right, 0, sw), m_alive(true)/*, m_dir(right), m_depth(0)*/, 
		m_landmines(0), m_flmthrw(0), m_vacc(0), m_infected(false), m_infection(0)/*, m_sw(sw)*/ {};
	virtual void doSomething();

private:
	bool m_alive;
	//int m_dir;
	//int m_depth;
	int m_landmines;
	int m_flmthrw;
	int m_vacc;
	bool m_infected;
	int m_infection;
	//StudentWorld* m_sw;
};

#endif // ACTOR_H_
