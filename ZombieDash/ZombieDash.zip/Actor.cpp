#include "Actor.h"
#include "StudentWorld.h"


// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp



void Penelope::doSomething() {
	if (!m_alive)
		return;
	if (m_infected) {
		if (m_infection < 500 && m_infection > 0)
			m_infection++;
		else if (m_infection >= 500) {
			m_alive = false;
			return;
		}	
	}
	int dir;
	//int dir = 1000; 
	
	if (getWorld()->getKey(dir)) {
	//if(1){
		switch (dir) {
			case KEY_PRESS_RIGHT:
				setDirection(right);
				if(!getWorld()->isBlocked(getX(), getY(), getDirection()))
					moveTo(getX() + 4, getY());
				break;
			case KEY_PRESS_LEFT:
				setDirection(left);
				if (!getWorld()->isBlocked(getX(), getY(), getDirection()))
					moveTo(getX() - 4, getY());
				break;
			case KEY_PRESS_UP:
				setDirection(up);
				if (!getWorld()->isBlocked(getX(), getY(), getDirection()))
					moveTo(getX(), getY() + 4);
				break;
			case KEY_PRESS_DOWN:
				setDirection(down);
				if (!getWorld()->isBlocked(getX(), getY(), getDirection()))
					moveTo(getX(), getY() - 4);
				break;
			default: break;
		}
	}
}
